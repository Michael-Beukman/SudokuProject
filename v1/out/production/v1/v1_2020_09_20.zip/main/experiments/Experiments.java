package main.experiments;

import main.Board;
import main.Solver;
import main.utils.SudokoBoardGen;

import java.util.Arrays;

public class Experiments {
    public static void main(String[] args) {
//            v1();
        v2();
    }

    private static void v1() {
        double average4 = doExp(4, 100);
        System.out.println(average4);

        double average9 = doExp(9, 100);
        System.out.println(average9);
        double average16 = doExp(16, 100);
        System.out.println(average16);
    }

    public static void v2() {
        for (int i=2; i<=3; ++i){
            double d[] = doOne(i*i, 100);
            System.out.println(Arrays.toString(d));
        }
    }

    public static double[] doOne(int size, int count){
        int numToDo = Math.min(size*size, 54);
        double[] arr = new double[size*size];

        for (int i =0 ;i < numToDo; ++i){
            if (size == 9) System.out.println(i);
            double a = doExp(size, count, i);
            arr[i] = a;
        }
        return arr;
    }

    private static double doExp(int size, int count) {

        double total = 0;
        for (int i=0;i<count; ++i){
            Board b = SudokoBoardGen.getBoard(size);
            Solver s = new Solver(b);
//            System.out.println("Done with making");
            long start = System.currentTimeMillis();
            Board newBoard = s.solve();
            // assert newBoard.isValid();
            long end = System.currentTimeMillis();
            total += end - start;
        }

        return total/count / 1000.0;
    }

    private static double doExp(int size, int count, int numEmptyCells){
        double total = 0;
        for (int i=0;i<count; ++i){
//            System.out.println(i);
            Board b = SudokoBoardGen.getBoard(size, numEmptyCells);
            Solver s = new Solver(b);
            long start = System.currentTimeMillis();
            Board newBoard = s.solve();
            // assert newBoard.isValid();
            long end = System.currentTimeMillis();
            total += end - start;
        }
        return total/count / 1000.0;
    }
}
