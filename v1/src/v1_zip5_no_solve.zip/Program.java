import main.Board;
import main.Solver;

import java.util.Scanner;

public class Program {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        StringBuilder s = new StringBuilder();
        while (scanner.hasNext()) {

            s.append(scanner.nextLine());
            if (scanner.hasNext()) s.append("\n");
        }

        Board b = new Board(s.toString());

//        Solver solver = new Solver(b);
//        Board ans = solver.solve();

        Board ans = b;
        System.out.println(ans.toString());
    }
}

